"use client";

import { useState, useRef, useEffect, useCallback } from "react";
import { ChevronDown } from "lucide-react";
import TooltipComponent from "../TooltipComponent/TooltipComponent.js";
import styles from "./SelectComponent.module.css";

/**
 * SelectComponent — custom dropdown that supports rendering arbitrary content
 * (icons, logos, etc.) in each option.
 *
 *  options:        [{ value, label, icon?, disabled?, tooltip? }]
 *  triggerTooltip  — optional tooltip shown on the trigger button hover
 */
export default function SelectComponent({
  value,
  options = [],
  onChange,
  placeholder = "Select...",
  icon = null,
  disabled = false,
  triggerTooltip = null,
}) {
  const [open, setOpen] = useState(false);
  const containerRef = useRef(null);

  const selected = options.find((o) => o.value === value);

  const handleSelect = useCallback(
    (opt) => {
      if (opt.disabled) return;
      onChange(opt.value);
      setOpen(false);
    },
    [onChange],
  );

  useEffect(() => {
    if (!open) return;
    const handleClick = (e) => {
      if (containerRef.current && !containerRef.current.contains(e.target)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const handleKey = (e) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("keydown", handleKey);
    return () => document.removeEventListener("keydown", handleKey);
  }, [open]);

  const renderOption = (opt) => {
    const btn = (
      <button
        key={opt.value}
        type="button"
        className={`${styles.option} ${opt.value === value ? styles.optionSelected : ""} ${opt.disabled ? styles.optionDisabled : ""}`}
        onClick={() => handleSelect(opt)}
        disabled={opt.disabled}
      >
        {opt.icon && (
          <span className={styles.optionIcon}>{opt.icon}</span>
        )}
        <span className={styles.optionLabel}>{opt.label}</span>
      </button>
    );

    if (opt.tooltip) {
      return (
        <TooltipComponent
          key={opt.value}
          label={opt.tooltip}
          position="right"
          delay={200}
        >
          {btn}
        </TooltipComponent>
      );
    }

    return btn;
  };

  const triggerButton = (
      <button
        type="button"
        className={`${styles.trigger} ${open ? styles.triggerOpen : ""} ${disabled ? styles.triggerDisabled : ""}`}
        onClick={() => !disabled && setOpen((prev) => !prev)}
        disabled={disabled}
      >
        <span className={styles.triggerContent}>
          {icon && <span className={styles.triggerIcon}>{icon}</span>}
          {!icon && selected?.icon && <span className={styles.optionIcon}>{selected.icon}</span>}
          <span className={styles.triggerLabel}>
            {selected ? selected.label : placeholder}
          </span>
        </span>
        <ChevronDown
          size={14}
          className={`${styles.chevron} ${open ? styles.chevronOpen : ""}`}
        />
      </button>
  );

  return (
    <div className={styles.dropdown} ref={containerRef}>
      <div className={styles.sizer} aria-hidden="true">
        {options.map((opt) => (
          <span key={opt.value} className={styles.sizerItem}>
            {icon && <span className={styles.triggerIcon}>{icon}</span>}
            {opt.icon && <span className={styles.optionIcon}>{opt.icon}</span>}
            <span>{opt.label}</span>
          </span>
        ))}
      </div>

      {triggerTooltip && !open ? (
        <TooltipComponent label={triggerTooltip} position="bottom" delay={400}>
          {triggerButton}
        </TooltipComponent>
      ) : (
        triggerButton
      )}

      {open && (
        <div className={styles.menu}>
          {options.map(renderOption)}
        </div>
      )}
    </div>
  );
}
